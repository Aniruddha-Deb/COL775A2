from slotformer.base_slots import build_dataset  # use the same dataset
